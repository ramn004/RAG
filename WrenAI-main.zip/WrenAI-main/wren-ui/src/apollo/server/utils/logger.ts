export { getLogger } from 'log4js';
