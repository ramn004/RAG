# LLamaTransforms

Namespace: LLama

A class that contains all the transforms provided internally by LLama.

```csharp
public class LLamaTransforms
```

Inheritance [Object](https://docs.microsoft.com/en-us/dotnet/api/system.object) → [LLamaTransforms](./llama.llamatransforms.md)

## Constructors

### **LLamaTransforms()**

```csharp
public LLamaTransforms()
```
