# LLamaKvCacheView

Namespace: LLama.Native

An updateable view of the KV cache (llama_kv_cache_view)

```csharp
public struct LLamaKvCacheView
```

Inheritance [Object](https://docs.microsoft.com/en-us/dotnet/api/system.object) → [ValueType](https://docs.microsoft.com/en-us/dotnet/api/system.valuetype) → [LLamaKvCacheView](./llama.native.llamakvcacheview.md)
