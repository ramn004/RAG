# BotSharp integration

The document is under work, please have a wait. Thank you for your support! :)