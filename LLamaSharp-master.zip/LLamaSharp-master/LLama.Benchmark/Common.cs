
namespace LLama.Benchmark
{
    public enum ExecutorType
    {
        Interactive,
        Instruct,
        Stateless
    }
}
