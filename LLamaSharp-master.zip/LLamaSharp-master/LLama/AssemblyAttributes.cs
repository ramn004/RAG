﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("LLama.Unittest")]