namespace LLama.Native;
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member

/// <summary>
/// 
/// </summary>
/// <remarks>llama_rope_type</remarks>
public enum LLamaRopeType
{
    None = -1,
    Norm = 0,
    //todo:NEOX = GGML_ROPE_TYPE_NEOX,
    //todo:MROPE = LLAMA_ROPE_TYPE_MROPE = GGML_ROPE_TYPE_MROPE,
    //todo:VISION = LLAMA_ROPE_TYPE_VISION = GGML_ROPE_TYPE_VISION,
}