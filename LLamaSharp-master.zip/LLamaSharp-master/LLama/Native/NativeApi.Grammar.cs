namespace LLama.Native
{
	public static partial class NativeApi
    {
	}
}
