namespace LLama.Native;

/// <summary>
/// C# representation of llama_kv_cache
/// </summary>
/// <remarks>llama_kv_cache</remarks>
internal struct LLamaKvCacheNative
{
    
}