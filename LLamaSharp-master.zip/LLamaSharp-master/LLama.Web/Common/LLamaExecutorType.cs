﻿namespace LLama.Web.Common
{
    public enum LLamaExecutorType
    {
        Interactive = 0,
        Instruct = 1,
        Stateless = 2
    }
}
