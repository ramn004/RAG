﻿namespace LLama.Web.Common
{
    public enum SessionConnectionStatus
    {
        Disconnected = 0,
        Loaded = 4,
        Connected = 10
    }
}
