---
nav_order: 3
has_children: true
parent: Extensions
title: Data formats
permalink: /extensions/data-formats
layout: default
---
# Data formats

* MS Word documents
* MS Excel spreadsheets
* MS PowerPoint presentations
* PDF documents
* Web pages
* JPG/PNG/TIFF Images with text via OCR
* MarkDown
* JSON
* Raw plain text
* [..] more coming :-)
