---
nav_order: 5
grand_parent: Extensions
parent: Memory DBs
title: Redis
permalink: /extensions/memory-db/redis
layout: default
---
# Redis

{: .highlight }
documentation under development
