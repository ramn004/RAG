---
nav_order: 100
grand_parent: Extensions
parent: Memory DBs
title: Simple memory
permalink: /extensions/dev-tools/simple-memory
layout: default
---
# Simple memory (dev/test tool)

{: .highlight }
documentation under development
