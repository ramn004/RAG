---
nav_order: 1
grand_parent: Extensions
parent: Memory DBs
title: Azure AI Search
permalink: /extensions/memory-db/azure-ai-search
layout: default
---
# Azure AI Search

{: .highlight }
documentation under development
