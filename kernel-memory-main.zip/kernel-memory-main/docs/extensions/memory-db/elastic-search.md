---
nav_order: 4
grand_parent: Extensions
parent: Memory DBs
title: Elastic Search
permalink: /extensions/memory-db/elastic-search
layout: default
---
# Elastic Search

{: .highlight }
documentation under development
