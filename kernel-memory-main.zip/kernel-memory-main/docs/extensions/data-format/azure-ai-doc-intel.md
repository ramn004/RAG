---
nav_order: 1
grand_parent: Extensions
parent: Data formats
title: Azure AI Document Intelligence
permalink: /extensions/data-formats/azure-ai-doc-intel
layout: default
---
# Azure AI Document Intelligence

{: .highlight }
documentation under development
