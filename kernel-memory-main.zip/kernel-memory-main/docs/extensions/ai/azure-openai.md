---
nav_order: 1
grand_parent: Extensions
parent: AI
title: Azure OpenAI
permalink: /extensions/ai/azure-openai
layout: default
---
# Azure OpenAI

{: .highlight }
documentation under development
