---
nav_order: 2
grand_parent: Extensions
parent: AI
title: OpenAI
permalink: /extensions/ai/openai
layout: default
---
# OpenAI

{: .highlight }
documentation under development
