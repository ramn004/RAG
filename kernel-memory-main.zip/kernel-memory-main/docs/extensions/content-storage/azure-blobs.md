---
nav_order: 1
grand_parent: Extensions
parent: Content storage
title: Azure Blobs
permalink: /extensions/content-storage/azure-blobs
layout: default
---
# Azure Blobs

{: .highlight }
documentation under development
