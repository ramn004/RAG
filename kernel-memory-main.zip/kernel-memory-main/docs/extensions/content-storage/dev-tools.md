---
nav_order: 2
grand_parent: Extensions
parent: Content storage
title: Simple storage
permalink: /extensions/dev-tools/simple-storage
layout: default
---
# Simple storage (dev/test tool)

{: .highlight }
documentation under development
