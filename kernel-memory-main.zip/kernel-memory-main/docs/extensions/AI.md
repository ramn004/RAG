---
nav_order: 2
has_children: true
parent: Extensions
title: AI
permalink: /extensions/ai
layout: default
---
# AI / LLM backends

{: .highlight }
documentation under development
