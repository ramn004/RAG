---
nav_order: 5
has_children: true
parent: Extensions
title: Content storage
permalink: /extensions/content-storage
layout: default
---
# Content storage

{: .highlight }
documentation under development
