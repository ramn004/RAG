---
nav_order: 100
grand_parent: Extensions
parent: Orchestration
title: Simple queues
permalink: /extensions/dev-tools/simple-queues
layout: default
---
# Simple queues (dev/test tool)

{: .highlight }
documentation under development
