---
nav_order: 1
grand_parent: Extensions
parent: Orchestration
title: Azure Queues
permalink: /extensions/orchestration/azure-queues
layout: default
---
# Azure Queues

{: .highlight }
documentation under development
