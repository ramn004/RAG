---
nav_order: 3
parent: Service
title: OpenAPI - Web API
permalink: /service/openapi
layout: default
---
# Web service OpenAPI

{: .highlight }
documentation under development
