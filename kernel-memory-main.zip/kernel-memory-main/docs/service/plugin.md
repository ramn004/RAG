---
nav_order: 6
parent: Service
title: SK Plugin
permalink: /service/sk-plugin
layout: default
---

# Semantic Kernel plugin

{: .highlight }
documentation under development
