---
nav_order: 1
parent: Serverless (.NET)
title: Components
permalink: /serverless/components
layout: default
---
# Components of serverless memory

{: .highlight }
documentation under development
