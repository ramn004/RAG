---
nav_order: 2
parent: Serverless (.NET)
title: Volatile memory
permalink: /serverless/volatile-memory
layout: default
---
# Serverless memory volatility

{: .highlight }
documentation under development
