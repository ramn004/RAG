---
nav_order: 4
parent: Serverless (.NET)
title: SK Plugin
permalink: /serverless/sk-plugin-serverless
layout: default
---

# Semantic Kernel plugin (serverless)

{: .highlight }
documentation under development
