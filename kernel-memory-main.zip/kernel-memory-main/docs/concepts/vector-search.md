---
nav_order: 8
parent: Concepts
title: Vector Search
permalink: /concepts/vector-search
layout: default
---
# Vector Search

{: .highlight }
documentation under development
