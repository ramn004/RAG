---
nav_order: 2
parent: Memory API
title: Answer questions (RAG)
permalink: /functions/answer-questions
layout: default
---
# API: answering questions

{: .highlight }
documentation under development
