---
nav_order: 3
parent: Memory API
title: Search memory
permalink: /functions/search-memory
layout: default
---
# API: searching memory

{: .highlight }
documentation under development
