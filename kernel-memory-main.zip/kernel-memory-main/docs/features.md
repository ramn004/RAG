---
nav_order: 13
has_children: true
title: Memory API
permalink: /functions
layout: default
---
# Memory API

{: .highlight }
documentation under development

Memory API:

* ImportDocumentAsync
* ImportTextAsync
* ImportWebPageAsync
* ListIndexesAsync
* DeleteDocumentAsync
* IsDocumentReadyAsync
* GetDocumentStatusAsync
* **SearchAsync**
* **AskAsync**