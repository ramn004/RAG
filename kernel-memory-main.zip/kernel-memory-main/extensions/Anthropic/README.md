# Kernel Memory with Anthropic LLMs

[![Discord](https://img.shields.io/discord/1063152441819942922?label=Discord&logo=discord&logoColor=white&color=d82679)](https://aka.ms/KMdiscord)

This project contains
the [Anthropic](https://www.anthropic.com/)
adapter allowing to use Anthropic LLMs in Kernel Memory.