﻿// Copyright (c) Microsoft. All rights reserved.

namespace Microsoft.KernelMemory.AI.Anthropic.Client;

internal abstract class StreamingResponseMessage;
