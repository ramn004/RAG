﻿# Kernel Memory with Azure AI Search

[![Nuget package](https://img.shields.io/nuget/v/Microsoft.KernelMemory.MemoryDb.AzureAISearch)](https://www.nuget.org/packages/Microsoft.KernelMemory.MemoryDb.AzureAISearch/)
[![Discord](https://img.shields.io/discord/1063152441819942922?label=Discord&logo=discord&logoColor=white&color=d82679)](https://aka.ms/KMdiscord)

This project contains the [Azure AI Search](https://azure.microsoft.com/products/ai-services/ai-search)
adapter allowing to use Kernel Memory with Azure AI Search.