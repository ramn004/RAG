# .NET Aspire for Kernel Memory

[![Discord](https://img.shields.io/discord/1063152441819942922?label=Discord&logo=discord&logoColor=white&color=d82679)](https://aka.ms/KMdiscord)

This project contains
[.NET Aspire](https://learn.microsoft.com/dotnet/aspire)
extensions to make it easier to run Kernel Memory locally
and in the cloud.