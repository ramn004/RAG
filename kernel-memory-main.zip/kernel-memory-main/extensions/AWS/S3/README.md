# Kernel Memory with AWS S3 Storage

This project contains the AWS S3 Storage adapter allowing Kernel Memory to
upload documents and maintain their state in AWS S3.
