# Text chunkers for Kernel Memory

[![Nuget package](https://img.shields.io/nuget/v/Microsoft.KernelMemory.Chunkers)](https://www.nuget.org/packages/Microsoft.KernelMemory.Chunkers/)
[![Discord](https://img.shields.io/discord/1063152441819942922?label=Discord&logo=discord&logoColor=white&color=d82679)](https://aka.ms/KMdiscord)

This project contains text chunkers, aka text partitioners, for Kernel Memory.
