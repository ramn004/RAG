﻿# Kernel Memory with RabbitMQ

[![Nuget package](https://img.shields.io/nuget/v/Microsoft.KernelMemory.Orchestration.RabbitMQ)](https://www.nuget.org/packages/Microsoft.KernelMemory.Orchestration.RabbitMQ/)
[![Discord](https://img.shields.io/discord/1063152441819942922?label=Discord&logo=discord&logoColor=white&color=d82679)](https://aka.ms/KMdiscord)

This project contains the [RabbitMQ](https://www.rabbitmq.com/) adapter allowing to orchestrate
Kernel Memory pipelines with RabbitMQ queues.
