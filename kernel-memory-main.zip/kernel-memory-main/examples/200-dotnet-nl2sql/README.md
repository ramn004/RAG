# Natural Language to SQL Console

Code moved to https://github.com/microsoft/kernel-memory/tree/NL2SQL/examples/200-dotnet-nl2sql
