## Example: Summarizing documents

This example shows how to use Kernel Memory to summarize documents and how
to retrieve the summaries at any time using the search API.

Summarization is just one example of synthetic data that can be generated
by custom handlers, so you can also reuse this example for any custom data
you plan to generate out of your documents.
