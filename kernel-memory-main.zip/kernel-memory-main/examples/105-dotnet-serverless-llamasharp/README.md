## Example: serverless Memory with Llama

This example shows how to use Llama models with the Serverless memory.

Note that Llama performance on local computers highly depend on the
hardware available. The example can take only few second or several seconds,
depending on the device used.
